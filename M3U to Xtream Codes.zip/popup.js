const generateBtn = document.getElementById("generateBtn");
const copiedMsg = document.getElementById("copied");

generateBtn.addEventListener("click", () => {
  const input = document.getElementById("m3uInput").value.trim();
  if (!input) return;

  try {
    const url = new URL(input);

    const username = url.searchParams.get("username");
    const password = url.searchParams.get("password");
    const server = url.hostname;
    const port = url.port || "80";

    if (!username || !password) {
      alert("Invalid M3U link. Username or password missing.");
      return;
    }

    document.getElementById("server").textContent = server;
    document.getElementById("port").textContent = port;
    document.getElementById("username").textContent = username;
    document.getElementById("password").textContent = password;
    document.getElementById("api").textContent =
      `${url.protocol}//${server}:${port}/player_api.php?username=${username}&password=${password}`;

    document.getElementById("result").classList.remove("hidden");
  } catch {
    alert("Invalid URL format.");
  }
});

document.querySelectorAll(".copy").forEach(btn => {
  btn.addEventListener("click", () => {
    const id = btn.getAttribute("data-copy");
    const text = document.getElementById(id).textContent;

    navigator.clipboard.writeText(text).then(() => {
      copiedMsg.classList.remove("hidden");
      setTimeout(() => copiedMsg.classList.add("hidden"), 1200);
    });
  });
});